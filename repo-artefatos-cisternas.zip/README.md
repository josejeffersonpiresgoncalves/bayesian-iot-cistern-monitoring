# Uma Arquitetura Adaptativa Baseada em Redes Bayesianas para Monitoramento Hídrico de Cisternas Rurais

Repositório de artefatos referentes à qualificação de mestrado apresentada ao
Programa de Pós-Graduação em Tecnologia da Informação (PPGTI) do Instituto
Federal de Educação, Ciência e Tecnologia da Paraíba (IFPB) — *Campus* João
Pessoa.

- **Autor:** José Jefferson Pires Gonçalves
- **Orientador:** Prof. Dr. Danyllo Alburquerque
- **Coorientador:** Prof. Dr. Bruno Neiva Moreno
- **Nível:** Mestrado Profissional
- **Ano:** 2026

## Resumo

Este trabalho propõe uma arquitetura adaptativa para monitoramento hídrico de
cisternas rurais no semiárido brasileiro, baseada em Redes Bayesianas como
mecanismo de apoio à decisão operacional sob incerteza. A rede integra
evidências relacionadas ao nível da cisterna, à confiabilidade da medição, à
precipitação, à condição energética do nó sensor e à qualidade do enlace de
comunicação (LoRaWAN), utilizando ESP32 e sensores de nível como componentes
de suporte à coleta e transmissão dos dados.

## Estrutura do repositório

```
├── paper/
│   └── qualificacao.pdf              # Documento completo da qualificação
├── model/
│   ├── rede_bayesiana.json           # Estrutura completa da rede (nós, arestas, CPTs)
│   └── rede_bayesiana.xmlbif         # Rede em formato XMLBIF (GeNIe, pgmpy, bnlearn)
├── data/
│   ├── priors.csv                    # Probabilidades a priori dos nós raiz
│   ├── cpt_risco_hidrico.csv         # CPT do nó Risco_Hidrico
│   ├── cpt_viabilidade_transmissao.csv
│   └── cpt_decisao_operacional.csv
├── figures/
│   └── estrutura_rede.svg            # Diagrama da estrutura da rede (DAG)
├── CITATION.cff
└── README.md
```

## Estrutura da Rede Bayesiana

**Nós de entrada (evidências observadas/estimadas):**
`Nivel_Cisterna`, `Incerteza_Medicao`, `Precipitacao`, `Qualidade_Enlace`, `Estado_Bateria`

**Nós intermediários (inferências):**
`Risco_Hidrico`, `Viabilidade_Transmissao`

**Nó de saída (decisão):**
`Decisao_Operacional`

Todos os nós são modelados, nesta versão preliminar, com dois estados
possíveis: `TRUE` e `FALSE`.

### Grafo de dependências (DAG)

```
Nivel_Cisterna        ─┐
Incerteza_Medicao     ─┼──► Risco_Hidrico ─────┐
Precipitacao           ─┘                       │
                                                  ├──► Decisao_Operacional
Qualidade_Enlace      ─┐                        │
Estado_Bateria         ─┴──► Viabilidade_Trans. ─┘
```

## Probabilidades a priori (nós raiz)

| Nó raiz | P(TRUE) | P(FALSE) |
|---|---|---|
| Nivel_Cisterna | 0,30 | 0,70 |
| Incerteza_Medicao | 0,25 | 0,75 |
| Precipitacao | 0,40 | 0,60 |
| Qualidade_Enlace | 0,70 | 0,30 |
| Estado_Bateria | 0,75 | 0,25 |

## CPT — Risco_Hidrico

| Nivel_Cisterna | Incerteza_Medicao | Precipitacao | P(TRUE) | P(FALSE) |
|---|---|---|---|---|
| TRUE | TRUE | TRUE | 0,45 | 0,55 |
| TRUE | TRUE | FALSE | 0,80 | 0,20 |
| TRUE | FALSE | TRUE | 0,60 | 0,40 |
| TRUE | FALSE | FALSE | 0,90 | 0,10 |
| FALSE | TRUE | TRUE | 0,05 | 0,95 |
| FALSE | TRUE | FALSE | 0,12 | 0,88 |
| FALSE | FALSE | TRUE | 0,03 | 0,97 |
| FALSE | FALSE | FALSE | 0,08 | 0,92 |

## CPT — Viabilidade_Transmissao

| Qualidade_Enlace | Estado_Bateria | P(TRUE) | P(FALSE) |
|---|---|---|---|
| TRUE | TRUE | 0,93 | 0,07 |
| TRUE | FALSE | 0,45 | 0,55 |
| FALSE | TRUE | 0,35 | 0,65 |
| FALSE | FALSE | 0,15 | 0,85 |

## CPT — Decisao_Operacional

| Risco_Hidrico | Viabilidade_Transmissao | P(TRUE) | P(FALSE) |
|---|---|---|---|
| TRUE | TRUE | 0,95 | 0,05 |
| TRUE | FALSE | 0,60 | 0,40 |
| FALSE | TRUE | 0,15 | 0,85 |
| FALSE | FALSE | 0,05 | 0,95 |

## Como usar os dados

Os arquivos CSV podem ser carregados diretamente com `pandas`:

```python
import pandas as pd
cpt = pd.read_csv("data/cpt_risco_hidrico.csv")
```

O arquivo `model/rede_bayesiana.xmlbif` pode ser aberto em ferramentas como
[GeNIe](https://www.bayesfusion.com/genie/), Hugin, ou lido em Python com a
biblioteca [`pgmpy`](https://pgmpy.org/):

```python
from pgmpy.readwrite import XMLBIFReader
reader = XMLBIFReader("model/rede_bayesiana.xmlbif")
model = reader.get_model()
```

## Cenários de validação (resultados preliminares)

| Cenário | Nível | Incerteza | Precip. | Enlace | Bateria | Risco Hídrico | Viab. Transmissão | Decisão Operacional |
|---|---|---|---|---|---|---|---|---|
| C1 — Operação normal | F | F | F | T | T | 8,00% | 92,00% | 9,94% |
| C2 — Risco c/ boa transmissão | T | F | F | T | T | 90,00% | 95,00% | 82,48% |
| C3 — Medição incerta | T | T | F | T | T | 65,00% | 95,00% | 62,81% |
| C4 — Baixa viabilidade | T | F | F | F | F | 90,00% | 5,00% | 38,92% |
| C5 — Sem risco, baixa operação | F | F | F | F | F | 5,00% | 5,00% | 8,33% |

## Licença

Defina aqui a licença desejada (sugestão: [CC-BY 4.0](https://creativecommons.org/licenses/by/4.0/)
para o texto/dados e [MIT](https://opensource.org/licenses/MIT) para eventual código).

## Como citar

Ver [`CITATION.cff`](./CITATION.cff).
